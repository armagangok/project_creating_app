"""When called as a script, consumes the input"""

import sys

if __name__ == "__main__":
    for line in sys.stdin:
        pass
